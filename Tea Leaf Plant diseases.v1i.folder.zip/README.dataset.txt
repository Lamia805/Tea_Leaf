# Tea Leaf Plant diseases > 2023-12-22 7:29pm
https://universe.roboflow.com/rrt/tea-leaf-plant-diseases

Provided by a Roboflow user
License: CC BY 4.0

